package LoginPageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory
{
	WebDriver driver;
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement pfusn;
	
	@FindBy(name="userPwd")
	@CacheLookup
	WebElement pfpwd;
	
	@FindBy(className="btn")
	@CacheLookup
	WebElement pfbtn;

	public LoginPageFactory(WebDriver driver) 
	{
		super();
		PageFactory.initElements(driver, this);
	}

	public WebElement getPfusn() 
	{
		return pfusn;
	}

	public void setPfusn(String sname)
	{
		pfusn.sendKeys(sname);
	}

	public WebElement getPfpwd()
	{
		return pfpwd;
	}

	public void setPfpwd(String spwd) 
	{
		pfpwd.sendKeys(spwd);
	}

	public WebElement getPfbtn() 
	{
		return pfbtn;
	}

	public void setPfbtn()
	{
		pfbtn.click();
	}
	
	
}
