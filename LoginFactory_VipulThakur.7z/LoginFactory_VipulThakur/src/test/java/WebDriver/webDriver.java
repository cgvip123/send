package WebDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import LoginPageBean.LoginPageFactory;

public class webDriver {

	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "C:/Users/VIPUTHAK/Desktop/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/VIPUTHAK/Desktop/login.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		LoginPageFactory objhbpg = new LoginPageFactory(driver);

		objhbpg.setPfusn("");Thread.sleep(1000);
		objhbpg.setPfpwd("asdasd");Thread.sleep(1000);
		objhbpg.setPfbtn();Thread.sleep(1000);
		Thread.sleep(1000);
		
		System.out.println(driver.findElement(By.id("userErrMsg")).getText());

		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userPwd")).clear();
		
		objhbpg.setPfusn("capgemini");Thread.sleep(1000);
		objhbpg.setPfpwd("");Thread.sleep(1000);
		objhbpg.setPfbtn();Thread.sleep(1000);
		
		Thread.sleep(1000);
		System.out.println(driver.findElement(By.id("pwdErrMsg")).getText());
	    
		driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userPwd")).clear();
		
	    objhbpg.setPfusn("asdasd");Thread.sleep(1000);
		objhbpg.setPfpwd("asdasd");Thread.sleep(1000);
		objhbpg.setPfbtn();Thread.sleep(1000);
		
		String invalidMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + invalidMessage);
	    System.out.println();
	    
	    driver.findElement(By.name("userName")).clear();
		driver.findElement(By.name("userPwd")).clear();
	    
	    objhbpg.setPfusn("capgemini");Thread.sleep(1000);
		objhbpg.setPfpwd("capg1234");Thread.sleep(1000);
		objhbpg.setPfbtn();Thread.sleep(1000);
	    
	}
}
